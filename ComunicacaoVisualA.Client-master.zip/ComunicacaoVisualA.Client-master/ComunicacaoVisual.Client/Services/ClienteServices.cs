﻿using FrontBase44.DTOs;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace ComunicacaoVisual.Client.Services
{
    public class ClienteService
    {
        private readonly HttpClient _http;

        public ClienteService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<ClienteDTO>> GetClientes()
        {
            return await _http.GetFromJsonAsync<List<ClienteDTO>>("api/clientes");
        }

        public async Task<ClienteDTO> GetClientePorId(int id)
        {
            return await _http.GetFromJsonAsync<ClienteDTO>($"api/clientes/{id}");
        }

        public async Task<HttpResponseMessage> CriarCliente(ClienteDTO cliente)
        {
            return await _http.PostAsJsonAsync("api/clientes", cliente);
        }
    }
}