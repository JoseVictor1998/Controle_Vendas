using ComunicacaoVisual.Client;
using ComunicacaoVisual.Client.Services;

using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

builder.RootComponents.Add<App>("#app");

builder.Services.AddScoped<FilaProducaoService>();
builder.Services.AddScoped<MeusPedidosVendedorService>();
builder.Services.AddScoped<ClienteService>();

builder.Services.AddScoped(sp => new HttpClient
{
    BaseAddress = new Uri("https://localhost:5001/")
});

await builder.Build().RunAsync();