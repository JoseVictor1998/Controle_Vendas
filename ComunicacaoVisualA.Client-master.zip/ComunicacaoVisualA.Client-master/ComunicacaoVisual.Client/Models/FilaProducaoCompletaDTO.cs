﻿namespace ComunicacaoVisual.Client.Models;

public class FilaProducaoCompletaDTO
{
    public int PedidoId { get; set; }

    public string OsExterna { get; set; } = string.Empty;

    public string ClienteNome { get; set; } = string.Empty;

    public string TipoProdutoNome { get; set; } = string.Empty;

    public decimal Largura { get; set; }

    public decimal Altura { get; set; }

    public int Quantidade { get; set; }

    public string? ObservacaoGeral { get; set; }

    public string? VendedorNome { get; set; }

    public string? CaminhoFoto { get; set; }

    public int StatusId { get; set; }

    public string StatusNome { get; set; } = string.Empty;

    public DateTime CreatedDate { get; set; }
}