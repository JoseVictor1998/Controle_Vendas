﻿namespace ComunicacaoVisual.Client.Models
{

    public class TipoProdutoDTO
    {

        public int Id { get; set; }

        public string Nome { get; set; } = string.Empty;

    }

}